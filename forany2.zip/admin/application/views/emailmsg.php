<div class='row'>
   <div class='col-md-6'>
    <img src='http://www.toy-kraft.com/media/logo/default/az_logo.png'>
    </div>
   <div class='col-md-6'>
   
   
    </div>
</div>
<div class='row'>
</div>
<div class='row'>
   <div class='col-md-12' style='padding: 44px 0 15px;font-size: 120%;'>
    Click Button To Download Reports<br>
    </div>
    <br>
    <div style='margin: 40px 0;'>
<!--    <a class='btn btn-primary' href='<?php echo $link;?>'> <input type='button' value='Download' style='text-align: center;padding: 20px 100px;background: #9B212E;margin-top: 26px;color: white;text-decoration: none;font-size: 120%;'></a> -->
   <a href="<?php echo $link;?>" target="_blank" style="text-align: center;padding: 20px 100px;background: #9B212E;margin-top: 44px;color: white;text-decoration: none;font-size: 120%;">Download</a>
    </div>
</div>