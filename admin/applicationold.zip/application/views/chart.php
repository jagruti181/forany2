

<?php echo $this->load->view('backend/includes/'.$page); ?>

