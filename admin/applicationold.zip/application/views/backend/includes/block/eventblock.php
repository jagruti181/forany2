<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editevent?id=').$before['event']->id; ?>">Event Details</a></li>
<li><a href="<?php echo site_url('site/editeventcategorytopic?id=').$before['event']->id; ?>">Event Category & Topic</a></li>
</ul>
</div>
</section>