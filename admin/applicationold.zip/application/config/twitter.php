<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['twitter_consumer_token']		= 'q6l4REBotnpk9TK8t7ZJygTgy';
$config['twitter_consumer_secret']		= 'h9CA0BBNyFQoiMnGkDQCZcA7CKQ4NlxuCiZ1rBg2rVKG03TAMd';
$config['twitter_access_token']			= '121427044-Q7j0z7uqIVR83TQZsGDSfrUP64cXtQ24GByIAKOF'; // Optional
$config['twitter_access_secret']		= 'tqMusTWB2189HWFhIsDybfAe509z2SWSxPjSIi1JkvTAZ'; // Optional

/* End of file twitter.php */
/* Location: ./application/config/twitter.php */